// includeA.h by Bill Weinman <http://bw.org/>

struct structA {
	int member;
};

