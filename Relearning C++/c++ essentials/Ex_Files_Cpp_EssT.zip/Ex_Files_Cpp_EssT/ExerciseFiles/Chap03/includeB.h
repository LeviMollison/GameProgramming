// includeB.h by Bill Weinman <http://bw.org/>

struct structB {
	int member;
};

