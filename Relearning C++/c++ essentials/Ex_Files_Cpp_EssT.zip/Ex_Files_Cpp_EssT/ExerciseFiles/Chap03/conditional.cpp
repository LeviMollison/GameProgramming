// conditional.c by Bill Weinman <http://bw.org/>
#include <cstdio>
#include "conditional.h"

int main( int argc, char ** argv ) {
	printf("Number is %d\n", NUMBER);
	return 0;
}
